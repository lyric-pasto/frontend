import mysql from "mysql2";

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "loomtrack"
});

db.connect(err => {
  if (err) throw err;
  console.log("✅ Conectado a la base de datos MySQL");
});

export default db;
