import { getUserByEmail } from "../models/LoginModel.js";

export const login = (req, res) => {
  const { email, password } = req.body;
  getUserByEmail(email, (err, results) => {
    if (err) return res.status(500).json({ error: err });
    if (results.length === 0) return res.status(404).json({ message: "Usuario no encontrado" });

    const user = results[0];
    if (user.password === password) {
      res.json({ message: "Login exitoso", user });
    } else {
      res.status(401).json({ message: "Contraseña incorrecta" });
    }
  });
};
import { getUserByEmail, createUser } from "../models/LoginModel.js";
export const register = (req, res) => {
  const { email, password, nombre } = req.body;
    getUserByEmail(email, (err, results) => {
    if (err) return res.status(500).json({ error: err });
    if (results.length > 0) return res.status(400).json({ message: "El usuario ya existe" });
    const newUser = { email, password, nombre };
    createUser(newUser, (err, results) => {
      if (err) return res.status(500).json({ error: err });
      res.status(201).json({ message: "Usuario registrado exitosamente", userId: results.insertId });
    }); 
    });
};