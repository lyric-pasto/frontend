import db from "../config/db.js";

export const getUserByEmail = (email, callback) => {
  db.query("SELECT * FROM usuarios WHERE email = ?", [email], callback);
};
export const createUser = (userData, callback) => {
  db.query("INSERT INTO usuarios SET ?", userData, callback);
}